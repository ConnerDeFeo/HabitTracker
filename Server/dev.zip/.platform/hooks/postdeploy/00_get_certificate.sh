#!/usr/bin/env bash
sudo certbot -n -d habittrackerapi-env.eba-6npmzimh.us-east-2.elasticbeanstalk.com --nginx --agree-tos --email ninjanerozz@gmail.com